# SWMM5 + EPANET Force Main Converter v2.0

Professional-grade hydraulic roughness translation tool for stormwater and water distribution modeling.

## Features

- **EPA SWMM5 Compliant**: Implements Reference Manual Vol. II, Section 7.3.3 equations
- **Uncertainty Quantification**: Displays ± ranges based on field measurement errors
- **Temperature Corrections**: Full support for 5-60°C water temperature effects
- **Reynolds Number Validation**: Real-time flow regime indicators
- **Multiple Formulas**: Hazen-Williams, Darcy-Weisbach (Swamee-Jain), Chezy-Manning
- **Batch Processing**: Convert entire pipe networks with CSV export
- **Automated Testing**: Unit tests validate against EPA manual examples

## Physics

### Hazen-Williams → Manning's n
```
n = 1.067 × (D/S₀)^0.04 / C
```

### Darcy-Weisbach → Manning's n (Swamee-Jain)
```
f = 1.325 / [ln(ε/(3.7D) + 5.74/Re^0.9)]²
n = √(f/185) × D^(1/6)
```

### Temperature-Dependent Viscosity
```
ν = 1.792×10⁻⁶ / (1 + 0.03368T + 0.000221T²)  [m²/s]
```

## Usage

1. Open in Replit or any web server
2. Select workflow mode (SWMM5 Only / EPANET ↔ SWMM5)
3. Enter pipe parameters (diameter, slope, roughness)
4. Set water temperature (critical for D-W calculations)
5. Read equivalent n value with uncertainty range

## References

- EPA (2020). SWMM5 Reference Manual Volume II: Hydraulics
- Swamee, P.K. & Jain, A.K. (1976). Explicit equations for pipe-flow problems. J. Hydraulics Division, ASCE, 102(5), 657-664.
- ASCE (1992). Design and Construction of Urban Stormwater Management Systems

## Disclaimer

This tool provides roughness coefficient translations for educational and preliminary design purposes. Results include uncertainty quantification based on typical field measurement errors. Final designs must be validated against EPA SWMM5 Reference Manual and local engineering standards.

## License

MIT License - See LICENSE file for details.

## Version

v2.0 - Professional release with uncertainty quantification and temperature corrections.
