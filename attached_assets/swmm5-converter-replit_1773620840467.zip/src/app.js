// SWMM5 + EPANET Force Main Converter v2.0
// Professional-grade hydraulic roughness translation tool
// EPA SWMM5 Reference Manual Vol. II, Section 7.3.3 compliant

// State management
let currentSource = 'hw';
let currentWorkflow = 'epanet';
let slopeChart = null;
let batchResults = [];

// Physical constants
const G = 32.174; // ft/s²

// Initialize on DOM ready
document.addEventListener('DOMContentLoaded', () => {
    updateCalculation();
    initSlopeChart();
    runUnitTests();
});

// Workflow modes
function setWorkflow(mode) {
    currentWorkflow = mode;
    ['swmm5', 'epanet', 'batch', 'test'].forEach(m => {
        const btn = document.getElementById('btn-' + m);
        if (m === mode) {
            btn.classList.add('tab-active');
            btn.classList.remove('bg-slate-800', 'text-slate-300');
        } else {
            btn.classList.remove('tab-active');
            btn.classList.add('bg-slate-800', 'text-slate-300');
        }
    });

    document.getElementById('epanet-banner').style.display = mode === 'epanet' ? 'block' : 'none';
    document.getElementById('batch-section').classList.toggle('hidden', mode !== 'batch');
    document.getElementById('test-section').classList.toggle('hidden', mode !== 'test');
    document.getElementById('main-converter').style.display = (mode === 'batch' || mode === 'test') ? 'none' : 'grid';
}

// Unit toggle
function setUnits(unit) {
    const isImperial = unit === 'imperial';
    document.getElementById('units-imperial').className = isImperial ? 
        'px-3 py-1.5 rounded bg-blue-600 text-white font-medium' : 
        'px-3 py-1.5 rounded bg-slate-700 text-slate-300 border border-slate-600';
    document.getElementById('units-metric').className = !isImperial ? 
        'px-3 py-1.5 rounded bg-blue-600 text-white font-medium' : 
        'px-3 py-1.5 rounded bg-slate-700 text-slate-300 border border-slate-600';
}

// Temperature update
function updateTemperature() {
    const T = parseInt(document.getElementById('temperature').value);
    document.getElementById('temp-display').textContent = `${T}°C (${Math.round(T * 1.8 + 32)}°F)`;
    document.getElementById('temp-val').textContent = T;
    document.getElementById('temp-warning').classList.toggle('hidden', T < 30);
}

// Source formula selector
function setSource(source) {
    currentSource = source;

    // Update button styles
    ['hw', 'dw', 'cm'].forEach(s => {
        const btn = document.getElementById('src-' + s);
        if (s === source) {
            btn.classList.add('ring-2', 'ring-blue-500', 'bg-blue-900/20');
            btn.classList.remove('bg-slate-800/50');
        } else {
            btn.classList.remove('ring-2', 'ring-blue-500', 'bg-blue-900/20');
            btn.classList.add('bg-slate-800/50');
        }
    });

    // Update input ranges
    const configs = {
        hw: { label: 'H-W C Factor', min: 60, max: 150, step: 1, val: 120, 
              minText: '60 (rough)', midText: '105', maxText: '150 (smooth)' },
        dw: { label: 'D-W ε (mm)', min: 0.001, max: 3.0, step: 0.001, val: 0.26,
              minText: '0.0015 (PVC)', midText: '0.5 (Concrete)', maxText: '3.0 (Old CI)' },
        cm: { label: "Manning's n", min: 0.008, max: 0.030, step: 0.001, val: 0.013,
              minText: '0.008 (smooth)', midText: '0.015', maxText: '0.030 (rough)' }
    };

    const cfg = configs[source];
    document.getElementById('source-label').textContent = cfg.label;
    document.getElementById('source-min').textContent = cfg.minText;
    document.getElementById('source-mid').textContent = cfg.midText;
    document.getElementById('source-max').textContent = cfg.maxText;

    const input = document.getElementById('source-value');
    input.min = cfg.min;
    input.max = cfg.max;
    input.step = cfg.step;
    input.value = cfg.val;

    updateCalculation();
}

// Toggle flow section
function toggleFlow() {
    const enabled = document.getElementById('enable-flow').checked;
    document.getElementById('flow-section').classList.toggle('hidden', !enabled);
    document.getElementById('reynolds-badge').classList.toggle('hidden', !enabled);
}

// Kinematic viscosity (temperature dependent)
// ν = 1.792e-6 / (1 + 0.03368*T + 0.000221*T²) m²/s, converted to ft²/s
function getKinematicViscosity(T_celsius) {
    const nu_m2s = 1.792e-6 / (1 + 0.03368 * T_celsius + 0.000221 * T_celsius * T_celsius);
    return nu_m2s * 10.764; // Convert to ft²/s
}

// Swamee-Jain explicit friction factor (1976)
// f = 1.325 / [ln(ε/(3.7D) + 5.74/Re^0.9)]²
// Valid for 10^-6 < ε/D < 10^-2 and 5000 < Re < 10^8, error < 1%
function getFrictionFactor(epsilon_ft, D_ft, Re) {
    if (Re < 2300) return 64 / Re; // Laminar
    const term = epsilon_ft / (3.7 * D_ft) + 5.74 / Math.pow(Re, 0.9);
    return 1.325 / Math.pow(Math.log(term), 2);
}

// Main calculation function
function updateCalculation() {
    // Get inputs
    const D_inches = parseFloat(document.getElementById('diameter').value);
    const D_ft = D_inches / 12;
    const S0 = parseFloat(document.getElementById('slope').value);
    const sourceVal = parseFloat(document.getElementById('source-value').value);
    const T = parseFloat(document.getElementById('temperature').value);
    const Q = parseFloat(document.getElementById('flow-rate').value);
    const showUncertainty = document.getElementById('uncertainty-toggle').checked;

    // Update displays
    document.getElementById('diameter-display').textContent = `${D_inches.toFixed(1)}" (${D_ft.toFixed(2)} ft)`;
    document.getElementById('slope-display').textContent = `${S0.toFixed(4)} (${(S0 * 100).toFixed(2)}%)`;
    document.getElementById('slope-warning').classList.toggle('hidden', S0 <= 0.01);
    document.getElementById('network-slope-warning').classList.toggle('hidden', S0 <= 0.005);

    // Calculate kinematic viscosity and Reynolds number
    const nu = getKinematicViscosity(T);
    const A = Math.PI * Math.pow(D_ft / 2, 2);
    const V = Q / A;
    const Re = (V * D_ft) / nu;

    // Update Reynolds display
    if (document.getElementById('enable-flow').checked) {
        document.getElementById('re-value').textContent = Re.toLocaleString('en-US', { maximumFractionDigits: 0 });
        document.getElementById('reynolds-badge').textContent = `Re: ${(Re / 1000).toFixed(0)}k`;

        // Flow regime indicator
        let color, text, pct;
        if (Re < 2300) {
            color = 'red';
            text = 'Laminar (Invalid)';
            pct = 10;
        } else if (Re < 4000) {
            color = 'amber';
            text = 'Transition (High Unc)';
            pct = 30;
        } else if (Re < 100000) {
            color = 'emerald';
            text = 'Turbulent (Valid)';
            pct = 60;
        } else {
            color = 'blue';
            text = 'Fully Turbulent (Best)';
            pct = 90;
        }

        document.getElementById('re-bar').style.width = `${pct}%`;
        document.getElementById('re-bar').className = `h-2 rounded-full bg-${color}-500`;
        document.getElementById('re-regime').innerHTML = 
            `<span class="w-2 h-2 rounded-full bg-${color}-500 pulse-dot"></span>` +
            `<span class="text-xs text-${color}-400 font-medium">${text}</span>`;
    }

    // Calculate equivalent n
    let targetN, nMin, nMax, sourceDisplay, calcDetails, sourceType;
    const uncertainty = currentSource === 'hw' ? 0.10 : 0.20;

    if (currentSource === 'hw') {
        // Hazen-Williams to Manning's n
        // n = 1.067 * (D/S0)^0.04 / C
        const term = Math.pow(D_ft / S0, 0.04);
        targetN = 1.067 * term / sourceVal;
        nMin = 1.067 * term / (sourceVal * (1 + uncertainty));
        nMax = 1.067 * term / (sourceVal * (1 - uncertainty));

        sourceDisplay = `C = ${sourceVal}`;
        sourceType = 'Hazen-Williams';
        calcDetails = `
            <div>D = ${D_ft.toFixed(2)} ft | S₀ = ${S0.toFixed(4)}</div>
            <div>(D/S₀)^0.04 = ${term.toFixed(3)}</div>
            <div class="text-emerald-400">n = 1.067 × ${term.toFixed(3)} / ${sourceVal} = ${targetN.toFixed(4)} → <span class="font-bold">${targetN.toFixed(2)}</span></div>
        `;
        document.getElementById('chart-c-value').textContent = sourceVal;

    } else if (currentSource === 'dw') {
        // Darcy-Weisbach to Manning's n using Swamee-Jain
        const epsilon_mm = sourceVal;
        const epsilon_ft = epsilon_mm / 304.8;
        const f = getFrictionFactor(epsilon_ft, D_ft, Re);
        targetN = Math.sqrt(f / 185) * Math.pow(D_ft, 1 / 6);
        nMin = targetN * 0.8;
        nMax = targetN * 1.2;

        sourceDisplay = `ε = ${sourceVal} mm`;
        sourceType = 'Darcy-Weisbach';
        calcDetails = `
            <div>D = ${D_ft.toFixed(2)} ft | ε = ${epsilon_mm.toFixed(3)} mm</div>
            <div>Re = ${Re.toLocaleString('en-US', { maximumFractionDigits: 0 })} @ ${T}°C</div>
            <div>f (Swamee-Jain) = ${f.toFixed(4)}</div>
            <div class="text-emerald-400">n = √(${f.toFixed(4)}/185) × ${D_ft.toFixed(2)}^(1/6) = ${targetN.toFixed(4)}</div>
        `;

    } else {
        // Direct Manning's n
        targetN = sourceVal;
        nMin = sourceVal * 0.9;
        nMax = sourceVal * 1.1;
        sourceDisplay = `n = ${sourceVal}`;
        sourceType = "Manning's";
        calcDetails = `<div class="text-emerald-400">Direct entry: n = ${targetN.toFixed(4)}</div>`;
    }

    // Update result displays
    document.getElementById('source-value-display').textContent = sourceDisplay;
    document.getElementById('result-source').textContent = sourceDisplay;
    document.getElementById('result-source-type').textContent = sourceType;
    document.getElementById('result-target').textContent = `n = ${targetN.toFixed(2)}`;
    document.getElementById('target-range').textContent = showUncertainty ? `${nMin.toFixed(2)} – ${nMax.toFixed(2)}` : '';
    document.getElementById('target-range').classList.toggle('hidden', !showUncertainty);
    document.getElementById('calc-details').innerHTML = calcDetails;

    // EPANET context
    if (currentWorkflow === 'epanet') {
        const tempNote = currentSource === 'hw' 
            ? `Temperature-independent (H-W limitation). At ${T}°C, D-W would vary ±15% vs H-W.`
            : `Temperature-corrected via Re at ${T}°C.`;

        document.getElementById('epanet-context').innerHTML = `
            <div class="text-xs font-semibold text-blue-400 mb-2">EPANET → SWMM5 Translation</div>
            <p class="text-sm text-slate-300">Enter <span class="mono text-emerald-400 font-bold">n = ${targetN.toFixed(2)}</span> 
            ${showUncertainty ? `(range: ${nMin.toFixed(2)}–${nMax.toFixed(2)})` : ''} in SWMM5.</p>
            <p class="text-xs text-slate-500 mt-2">${tempNote}</p>
        `;
    }

    // Headloss calculations
    const R = D_ft / 4;

    // Manning headloss: Sf = (nQ/(1.49*A*R^(2/3)))^2
    const Sf_manning = Math.pow((targetN * Q) / (1.49 * A * Math.pow(R, 2 / 3)), 2);
    const hl_manning = Sf_manning * 1000;

    // Hazen-Williams headloss
    let hl_hw;
    if (currentSource === 'hw') {
        const Sf_hw = Math.pow((Q / (1.318 * sourceVal * A * Math.pow(R, 0.63))), 1 / 0.54);
        hl_hw = Sf_hw * 1000;
    } else {
        const term = Math.pow(D_ft / S0, 0.04);
        const equivC = 1.067 * term / targetN;
        const Sf_hw = Math.pow((Q / (1.318 * equivC * A * Math.pow(R, 0.63))), 1 / 0.54);
        hl_hw = Sf_hw * 1000;
    }

    // Darcy-Weisbach headloss
    const epsilon_est = currentSource === 'dw' ? sourceVal / 304.8 : 0.26 / 304.8;
    const f_dw = getFrictionFactor(epsilon_est, D_ft, Re);
    const Sf_dw = (f_dw * Math.pow(V, 2)) / (2 * G * D_ft);
    const hl_dw = Sf_dw * 1000;

    document.getElementById('headloss-flow').textContent = Q.toFixed(1);
    document.getElementById('hl-manning').textContent = `${hl_manning.toFixed(2)} ft/1000ft`;
    document.getElementById('hl-hw').textContent = `${hl_hw.toFixed(2)} ft/1000ft`;
    document.getElementById('hl-dw').textContent = `${hl_dw.toFixed(2)} ft/1000ft`;

    // Update slope chart
    updateSlopeChart(D_ft, sourceVal);
}

// Initialize slope sensitivity chart
function initSlopeChart() {
    const ctx = document.getElementById('slopeChart').getContext('2d');
    slopeChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [
                {
                    label: 'n (nominal)',
                    data: [],
                    borderColor: '#60a5fa',
                    backgroundColor: 'rgba(96, 165, 250, 0.1)',
                    tension: 0.4,
                    borderWidth: 2
                },
                {
                    label: 'Upper (+10%)',
                    data: [],
                    borderColor: 'rgba(148, 163, 184, 0.3)',
                    borderDash: [5, 5],
                    pointRadius: 0,
                    fill: '+1'
                },
                {
                    label: 'Lower (-10%)',
                    data: [],
                    borderColor: 'rgba(148, 163, 184, 0.3)',
                    borderDash: [5, 5],
                    pointRadius: 0,
                    fill: '-1'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: { color: '#94a3b8', font: { size: 11 } }
                }
            },
            scales: {
                x: {
                    type: 'logarithmic',
                    title: { display: true, text: 'Slope S₀', color: '#64748b' },
                    grid: { color: 'rgba(148, 163, 184, 0.1)' },
                    ticks: { color: '#64748b' }
                },
                y: {
                    title: { display: true, text: "Equivalent n", color: '#64748b' },
                    grid: { color: 'rgba(148, 163, 184, 0.1)' },
                    ticks: { color: '#64748b' }
                }
            }
        }
    });
}

// Update slope chart
function updateSlopeChart(D, C) {
    if (!slopeChart || currentSource !== 'hw') {
        if (slopeChart) {
            slopeChart.data.datasets[0].data = [];
            slopeChart.update();
        }
        return;
    }

    const slopes = [0.0001, 0.0002, 0.0005, 0.001, 0.002, 0.005, 0.01, 0.02, 0.05];
    const nValues = slopes.map(S0 => {
        const term = Math.pow(D / S0, 0.04);
        return 1.067 * term / C;
    });

    slopeChart.data.labels = slopes.map(s => s.toFixed(4));
    slopeChart.data.datasets[0].data = nValues;
    slopeChart.data.datasets[1].data = nValues.map(n => n * 1.1);
    slopeChart.data.datasets[2].data = nValues.map(n => n * 0.9);
    slopeChart.update();
}

// Run unit tests
function runUnitTests() {
    const tests = [
        {
            name: 'EPA Manual Example: H-W C=120, D=24", S=0.001',
            test: () => {
                const D = 24 / 12, S = 0.001, C = 120;
                const n = 1.067 * Math.pow(D / S, 0.04) / C;
                return Math.abs(n - 0.0121) < 0.0001;
            }
        },
        {
            name: 'Swamee-Jain: Re=100,000, ε/D=0.0002',
            test: () => {
                const f = 1.325 / Math.pow(Math.log(0.0002 / 3.7 + 5.74 / Math.pow(100000, 0.9)), 2);
                return f > 0.018 && f < 0.022;
            }
        },
        {
            name: 'Kinematic Viscosity at 15°C ≈ 1.22e-5 ft²/s',
            test: () => {
                const nu = (1.792e-6 / (1 + 0.03368 * 15 + 0.000221 * 225)) * 10.764;
                return Math.abs(nu - 1.22e-5) < 0.1e-5;
            }
        },
        {
            name: 'Laminar Flow: Re=2000, f=64/Re=0.032',
            test: () => {
                return Math.abs(64 / 2000 - 0.032) < 0.001;
            }
        }
    ];

    let html = '';
    let passed = 0;

    tests.forEach(t => {
        try {
            const result = t.test();
            passed += result ? 1 : 0;
            const color = result ? 'emerald' : 'red';
            const icon = result ? '✓' : '✗';
            html += `
                <div class="flex justify-between p-3 bg-slate-800/50 rounded-lg border border-slate-700">
                    <span class="text-sm text-slate-300">${t.name}</span>
                    <span class="text-${color}-400 font-bold">${icon}</span>
                </div>
            `;
        } catch (e) {
            html += `
                <div class="flex justify-between p-3 bg-slate-800/50 rounded-lg border border-slate-700">
                    <span class="text-sm text-slate-300">${t.name}</span>
                    <span class="text-red-400 text-xs">ERROR</span>
                </div>
            `;
        }
    });

    html += `
        <div class="mt-4 p-3 bg-slate-800 rounded-lg text-center">
            <span class="text-lg font-bold ${passed === tests.length ? 'text-emerald-400' : 'text-amber-400'}">${passed}/${tests.length}</span>
            <span class="text-sm text-slate-400 ml-2">tests passed</span>
        </div>
    `;

    document.getElementById('test-results').innerHTML = html;
}

// Batch processing
function processBatch() {
    const input = document.getElementById('batch-input').value.trim();
    if (!input) return;

    const lines = input.split('\n');
    batchResults = [];
    let output = 'D(in),Slope,Source,Temp(C),n_nominal,n_min,n_max,Re,Regime\n';

    lines.forEach(line => {
        const parts = line.split(',').map(p => parseFloat(p.trim()));
        if (parts.length >= 3 && !isNaN(parts[0])) {
            const D_in = parts[0];
            const D_ft = D_in / 12;
            const S0 = parts[1];
            const src = parts[2];
            const T = parts[3] || 15;

            let n, nMin, nMax;

            if (currentSource === 'hw') {
                const term = Math.pow(D_ft / S0, 0.04);
                n = 1.067 * term / src;
                nMin = 1.067 * term / (src * 1.1);
                nMax = 1.067 * term / (src * 0.9);
            } else if (currentSource === 'dw') {
                const nu = getKinematicViscosity(T);
                const Q = 3;
                const A = Math.PI * Math.pow(D_ft / 2, 2);
                const V = Q / A;
                const Re = (V * D_ft) / nu;
                const f = getFrictionFactor(src / 304.8, D_ft, Re);
                n = Math.sqrt(f / 185) * Math.pow(D_ft, 1 / 6);
                nMin = n * 0.8;
                nMax = n * 1.2;
            } else {
                n = src;
                nMin = src * 0.9;
                nMax = src * 1.1;
            }

            // Calculate Re for regime
            const nu = getKinematicViscosity(T);
            const Q = 3;
            const A = Math.PI * Math.pow(D_ft / 2, 2);
            const V = Q / A;
            const Re = (V * D_ft) / nu;
            const regime = Re > 100000 ? 'FullyTurb' : Re > 4000 ? 'Turbulent' : 'Transition';

            batchResults.push({ D: D_in, S0, src, T, n, nMin, nMax, Re, regime });
            output += `${D_in},${S0},${src},${T},${n.toFixed(3)},${nMin.toFixed(3)},${nMax.toFixed(3)},${Math.round(Re)},${regime}\n`;
        }
    });

    document.getElementById('batch-output').innerHTML = `<pre class="mono text-xs">${output}</pre>`;
    document.getElementById('download-btn').disabled = false;
}

// Download batch results as CSV
function downloadCSV() {
    if (batchResults.length === 0) return;

    let csv = 'Diameter(in),Slope,SourceValue,Temp_C,n_nominal,n_min,n_max,Reynolds,FlowRegime\n';
    batchResults.forEach(r => {
        csv += `${r.D},${r.S0},${r.src},${r.T},${r.n.toFixed(4)},${r.nMin.toFixed(4)},${r.nMax.toFixed(4)},${Math.round(r.Re)},${r.regime}\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'swmm5_conversion.csv';
    a.click();
    URL.revokeObjectURL(url);
}
