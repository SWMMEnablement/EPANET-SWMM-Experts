# EPANET for SWMM5 Experts — The Rosetta Stone

**v1.0 · March 2026**

The most comprehensive SWMM↔EPANET translation resource. Built by Robert E. Dickinson with 50+ years of hydraulic modeling experience.

## What's Inside

A single-file interactive web app (238 KB, zero dependencies) with 11 tabs:

1. **The Big Flip** — Animated pipe cross-sections, HGL blend slider, live Manning vs H-W calculations
2. **Objects Map** — Every SWMM5 object mapped to EPANET (with deep dives on mixing models, energy costs, cross-sections)
3. **Demands** — Complete DWF→Base Demand translation, demand categories, emitters, PDA vs DDA
4. **Hydraulics** — Manning's vs Hazen-Williams side by side, three headloss formula options
5. **The Solver** — Full Saint-Venant equations, CFL condition, Preissmann slot, vs Todini-Pilati Gradient Algorithm
6. **Water Quality** — Chlorine decay, water age, source tracing (both SWMM and EPANET approaches)
7. **Rules & Controls** — Nearly identical IF-THEN syntax compared side by side
8. **File Format** — .INP section mapping with 22+ rows
9. **Calculator** — Manning vs H-W headloss, Force Main n↔C converter (dual formula modes with actual SWMM5 source code), Darcy-Weisbach
10. **Gotchas** — 5 critical pitfalls for SWMM veterans
11. **Which Tool?** — Decision flowchart, convergence crosswalk, working example, transient checklist

## Features

- US/SI unit toggle (propagates globally)
- URL hash persistence (bookmark/share calculator states)
- Downloadable equations reference (📄 Docs button)
- Print stylesheet for Ctrl+P
- ARIA accessibility + keyboard navigation
- 10 automated equation validation tests (open browser console)
- Self-contained — works offline, no external dependencies

## Running Locally

```bash
node server.js
```

Open http://localhost:3000

## Dedicated to Dr. Lewis A. Rossman

Creator of EPANET at the US EPA (1991–2014). Every pressurized pipe model in the world traces back to his work.

## Links

- [SWMM5.org](https://www.swmm5.org)
- [Robert Dickinson on LinkedIn](https://www.linkedin.com/in/robertdickinson/)
- [Open Water Analytics — EPANET](https://github.com/OpenWaterAnalytics/EPANET)
